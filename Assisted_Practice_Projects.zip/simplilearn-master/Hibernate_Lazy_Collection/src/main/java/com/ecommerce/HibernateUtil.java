package com.ecommerce;

public class HibernateUtil {

}
